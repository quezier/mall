# mall
* 第一步：生成路由，http://主机/testcreaterou/etable_name/英文表名/ctable_name/中文表名/module_name/模块名
 * 第二步：生成Logic, http://主机/testcreatelog/etable_name/英文表名/ctable_name/中文表名/module_name/模块名
 * 第三步：生成controller, http://主机/testcreatecon/etable_name/英文表名/ctable_name/中文表名/module_name/模块名
