<?php
/**
 * @package        EzMvcPHP
 * @author         quezier
 * @email          33590896@qq.com
 */
return array(
    'router',
    'test',
    'admin',
    'admin/admin_main',
    'admin/admin_distributeprivilege',
    'admin/admin_privilege',
    'admin/admin_role',
    'admin/admin_admin',
    'admin/admin_first_level',
    'admin/admin_article_info',
    'admin/admin_article_type',
    'admin/admin_data_dictionary_type',
    'admin/admin_data_dictionary',
    'admin/admin_system_config',
    'admin/admin_goods',
    'admin/admin_goods_attr',
    'admin/admin_brand',
    'admin/admin_brand_series',
    'admin/admin_goods_category',
    'admin/admin_user',
);


